﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ACM.bl;

namespace ACM.BLTest
{
    [TestClass]
    public class CustomerTest
    {
        [TestMethod]
        public void FullNameTestValid()
        {
            //Arrange
            Customer customer = new Customer()
            {
                FirstName = "Suyash"
            };
            string expected = "Suyash";
            //Act
            String actual = customer.FullName;

            //Assert
            Assert.AreEqual(expected, actual);

        }

        [TestMethod]
        public void StaticTest()
        {
            var c1 = new Customer();
            c1.FirstName = "ankur";
            Customer.InstanceCount += 1;

            var c2 = new Customer();
            c1.FirstName = "Mayank";
            Customer.InstanceCount += 1;

            var c3 = new Customer();
            c1.FirstName = "Deepak";
            Customer.InstanceCount += 1;
        }

        [TestMethod]
        public void ValidateValid()
        {
            var customer = new Customer
            {
                LastName = "Tripathi",
                EmailAddress = "suyashtripathi98@gmail.com"
            };

            var expected = true;

            var actual = customer.Validate();

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ValidateMisingLastName()
        {
            var customer = new Customer()
            {
                EmailAddress = "suyashtripathi8@gmail.com"
            };

            var expected = false;

            var actual = customer.Validate();

            Assert.AreEqual(expected, actual);
        }
    }
}
