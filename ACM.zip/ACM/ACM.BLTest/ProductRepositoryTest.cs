﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ACM.bl;

namespace ACM.BLTest
{
    [TestClass]
    public class ProductRepositoryTest
    {
        [TestMethod]
        public void RetrieveTest()
        {
            var productRepository = new ProductRepository();
            var expected = new Product(2)
            {
                ProductName = "Iphones",
                ProductDescription = "Iphone 12 With A14 bionic chipset",
                CurrentPrice = 80000
        };
            //Act--
            var actual = productRepository.Retrieve(2);

            //Assert--

            Assert.AreEqual(expected.CurrentPrice, actual.CurrentPrice);
            Assert.AreEqual(expected.ProductDescription, actual.ProductDescription);
            Assert.AreEqual(expected.ProductName, actual.ProductName);
        }

        [TestMethod]
        public void SaveTestValid()
        {
            //Arrange
            var productRepository = new ProductRepository();
            var updatedProduct = new Product(2)
            {
                ProductName = "Iphones",
                ProductDescription = "Iphone 12 With A14 bionic chipset",
                CurrentPrice = 80000,
                HasChange = true
            };

            //Act--
            var actual = productRepository.Save(updatedProduct);

            //Assert--

            Assert.AreEqual(true, actual);
        }

        [TestMethod]
        public void SaveTestMissingPrice()
        {
            //Arrange
            var productRepository = new ProductRepository();
            var updatedProduct = new Product(2)
            {
                CurrentPrice = null,
                ProductDescription = "Iphone 12 With A14 bionic chipset",
                ProductName = "Iphones",
                HasChange = false
            };

            //Act--
            var actual = productRepository.Save(updatedProduct);

            //Assert--
            // i have to put false here
            Assert.AreEqual(true, actual);
        }
    }
}
