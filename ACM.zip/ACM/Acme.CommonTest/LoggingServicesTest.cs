﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Acme.Common;
using ACM.bl;

namespace Acme.CommonTest
{
    [TestClass]
    public class LoggingServicesTest
    {
        [TestMethod]
        public void WriteToListTest()
        {
            //Arrange
            var changedItems = new List<ILoggable>();
            var customer = new Customer(1)
            {
                EmailAddress = "suyashtripathi98@gmail.com",
                FirstName = "Suyash",
                LastName = "Tripathi",
                AddressList = null

            };
            changedItems.Add(customer);

            var product = new Product(2)
            {
                ProductName = "Iphone",
                ProductDescription = "Most Expensive",
                CurrentPrice = 80000
            };
            changedItems.Add(product);
            //Act
            LoggingService.WriteToFile(changedItems);

            //Assert
            //there is nothing to Assert
        }
    }
}
