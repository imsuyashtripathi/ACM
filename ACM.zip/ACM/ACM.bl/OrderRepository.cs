﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.bl
{
    public class OrderRepository
    {
        //retrieve one product
        public Order Retrieve(int orderId)
        {
            //instance of the product class
            Order order = new Order(orderId);

            //code that retrieves the defined product
            if (orderId == 10)
            {
                order.OrderDate = new DateTimeOffset(DateTime.Now.Year, 4, 14, 10, 00, 00, new TimeSpan(7, 0, 0));
            }
            return order;
        }

        //save the current product
        public bool save(Order order)
        {
            return true;
        }
    }
}
