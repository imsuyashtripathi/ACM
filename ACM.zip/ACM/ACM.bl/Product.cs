﻿using Acme.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.bl
{
    public class Product : EntityBase,ILoggable
    {
        public Product()
        {

        }
        public Product(int productId)
        {
            ProductId = productId;
        }

        public decimal? CurrentPrice { get; set; }
        public string ProductDescription { get; set; }
        public int ProductId { get; set; }
        private string _ProductName;

        public string ProductName
        {
            get
            {
                return _ProductName.InsertSpaces();
            }
            set
            {
                _ProductName = value;
            }
        }

        public string Log() => $"{ProductId}: {ProductName}Detail: {ProductDescription}Status:{EntityState.ToString()}";

        public override string ToString() => ProductName;
        // Validate Product data
        public override bool Validate()
        {
            var IsValid = true;

            if (string.IsNullOrWhiteSpace(ProductName)) IsValid = false;
            if (CurrentPrice==null) IsValid = false;

            return IsValid;
        }

    }
}
