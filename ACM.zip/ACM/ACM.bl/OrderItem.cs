﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.bl
{
    public class OrderItem
    {
        public OrderItem()
        { 

        }
        public OrderItem(int orderItemId)
        {
            OrderItemId = orderItemId;
        }
        
        public int OrderItemId { get; set; }
        public int ProductId { get; set; }
        public decimal? PurchasePrice { get; set; }
        public int Quantity { get; set; }

        //Retrieve one orderitem
        public OrderItem Retrieve(int OrderItemId)
        {
            return new OrderItem();
        }

        //Saves the current orderitem
        public bool Save()
        {
            return true;
        }
        // Validate orderitem data
        public bool Validate()
        {
            var isValid = true;
            if (Quantity <= 0) isValid = false;
            if (ProductId <= 0) isValid = false;
            if (PurchasePrice == null) isValid = false;

            return isValid;
        }
    }
}
