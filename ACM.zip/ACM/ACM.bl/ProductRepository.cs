﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.bl
{
    public class ProductRepository
    {
        //retrieve one product
        public Product Retrieve(int productId)
        {
            //instance of the product class
            Product product = new Product(productId);

            //code that retrieves the defined product
            if (productId == 2)
            {
                product.ProductName = "Iphones";
                product.ProductDescription = "Iphone 12 With A14 bionic chipset";
                product.CurrentPrice = 80000;
            }
            Object myObject = new Object();
            Console.WriteLine($"Object: {myObject.ToString()}");
            Console.WriteLine($"Product: {product.ToString()}");
            return product;
            
        }

        //save the current product
        public bool Save(Product product)
        {
            var success = true;
            if (product.HasChange)
            {
                if (product.IsValid)
                {
                    if (product.IsNew)
                    {
                        //Call an insert procedure
                    }
                    else
                    {
                        //Call and update procedure
                    }
                }
            }
            return success;
        }
    }
}
