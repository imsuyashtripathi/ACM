﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ACM.bl;
using Microsoft.VisualBasic

namespace ACM.BLTest
{
    [TestClass]
    public class CustomerTest
    { 
        [TestMethod]
        public void FullNameTestValid()
        {
            //Arrange
            Customer customer = new Customer
            {
                FirstName = "Suyash";
                LastName = "tripathi";
            };
           
            string expected = customer.FullName;
            ////-Act
            string actual = customer.FullName;

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
